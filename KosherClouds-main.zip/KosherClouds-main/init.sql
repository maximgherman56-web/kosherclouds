CREATE DATABASE "kosherclouds_userservice";
CREATE DATABASE "kosherclouds_productservice";
CREATE DATABASE "kosherclouds_orderservice";
CREATE DATABASE "kosherclouds_paymentservice";
CREATE DATABASE "kosherclouds_bookingservice";
CREATE DATABASE "kosherclouds_reviewservice";