export { Input } from './Input';
export type { InputProps } from './Input';