﻿namespace KosherClouds.ProductService.DTOs.Product
{
    public class SubCategoryDto
    {
        public string Value { get; set; } = string.Empty;
        public string Label { get; set; } = string.Empty;
        public string LabelUk { get; set; } = string.Empty;
    }
}
