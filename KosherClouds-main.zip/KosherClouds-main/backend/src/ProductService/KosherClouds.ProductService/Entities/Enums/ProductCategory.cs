namespace KosherClouds.ProductService.Entities.Enums;
public enum ProductCategory
{
    Dish,
    Set,
    Dessert,
    Drink,
    Hookah
}