namespace KosherClouds.ProductService.Entities.Enums;

public enum HookahStrength
{
    Light,
    Medium,
    Strong
}