﻿namespace KosherClouds.ReviewService.Entities
{
    public enum ReviewStatus
    {
        Published,
        Hidden,
        Deleted
    }
}
