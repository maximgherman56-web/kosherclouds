﻿namespace KosherClouds.ReviewService.Entities
{
    public enum ReviewType
    {
        Order,
        Product
    }
}
