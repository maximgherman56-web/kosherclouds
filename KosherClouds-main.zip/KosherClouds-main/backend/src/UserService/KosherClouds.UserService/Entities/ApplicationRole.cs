﻿using Microsoft.AspNetCore.Identity;

namespace KosherClouds.UserService.Entities
{
    public class ApplicationRole : IdentityRole<Guid>
    {
    }
}
