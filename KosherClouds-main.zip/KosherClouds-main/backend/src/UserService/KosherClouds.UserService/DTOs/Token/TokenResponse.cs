﻿namespace KosherClouds.UserService.DTOs.Token
{
    public record TokenResponse(string AccessToken, string RefreshToken);
}
