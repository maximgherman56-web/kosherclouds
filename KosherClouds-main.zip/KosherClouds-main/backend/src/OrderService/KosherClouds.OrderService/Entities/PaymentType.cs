﻿namespace KosherClouds.OrderService.Entities
{
    public enum PaymentType
    {
        OnPickup = 0,
        Online = 1
    }
}
