﻿namespace KosherClouds.OrderService.DTOs.External
{
    public class CartItemDto
    {
        public Guid ProductId { get; set; }
        public int Quantity { get; set; }
    }
}
