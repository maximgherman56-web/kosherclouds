﻿namespace KosherClouds.BookingService.Entities
{
    public enum BookingZone
    {
        Terrace,
        MainHall,
        VIP
    }
}
