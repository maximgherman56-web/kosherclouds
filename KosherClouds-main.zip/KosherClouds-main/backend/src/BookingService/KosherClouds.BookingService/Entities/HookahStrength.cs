﻿namespace KosherClouds.BookingService.Entities
{
    public enum HookahStrength
    {
        Light,
        Medium,
        Strong
    }
}
