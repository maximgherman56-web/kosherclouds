﻿namespace KosherClouds.BookingService.Entities
{
    public enum BookingStatus
    {
        Pending,
        Confirmed,
        Cancelled,
        Completed,
        NoShow
    }
}
